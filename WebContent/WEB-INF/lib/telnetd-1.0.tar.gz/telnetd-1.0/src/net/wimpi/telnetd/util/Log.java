//License 
/***
 * Java TelnetD library (embeddable telnet daemon)
 * Copyright (c) 2000-04 Dieter Wimberger 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 * Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * Neither the name of the author nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *  
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTORS ``AS
 * IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 * POSSIBILITY OF SUCH DAMAGE.
 ***/
package net.wimpi.telnetd.util;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;


/**
 * Class that implements a simple logging facility.<br>
 * It allows construction of an abstract stream log, and
 * offers an implemented file log version for convenience.
 *
 * @author Dieter Wimberger
 * @version 1.0 (16/01/2004)
 */
public class Log {

  //Members
  private SimpleDateFormat m_DateFormat;
  private OutputStreamWriter m_Writer;
  private ByteArrayOutputStream m_ByteOut;
  private PrintWriter m_PrintWriter;
  private String m_StackTrace;
  private boolean m_Active = true;

  /**
   * Private constructor, means clients need to use the
   * available factory methods.
   */
  private Log(OutputStreamWriter wri, String stampformat) {
    //set writer
    m_Writer = wri;
    //prepare dateformat
    m_DateFormat = new SimpleDateFormat(stampformat);
    //prepare streams for stacktracewriting
    m_ByteOut = new ByteArrayOutputStream(512);
    m_PrintWriter = new PrintWriter(m_ByteOut);
  }//constructor


  /**
   * Method to write a message to the log.
   *
   * @param msg String that represents the message to be written.
   */
  public synchronized void write(String msg) {
    if (!m_Active) {
      return;
    } else {
      try {
        m_Writer.write(getLogDateTime() + " " + msg + "\n");
        m_Writer.flush();
      } catch (Exception ex) {
        //log failure will dump shit to screen , well thats ok
        ex.printStackTrace();
      }
    }
  }//write

  /**
   * Method to write a message to the log.
   *
   * @param ex Exception to be written to the log.
   */
  public synchronized void writeStackTrace(Exception ex) {
    if (!m_Active) {
      return;
    } else {
      try {
        ex.printStackTrace(m_PrintWriter);
        m_PrintWriter.flush();
        m_StackTrace = "Exception occured:\n" + m_ByteOut.toString() + "\n";
      } catch (Exception exc) {
        m_StackTrace = "Logging exception failed.";
      } finally {
        //empty the bytebuffer
        m_ByteOut.reset();
      }
      write(m_StackTrace);
    }
  }//logStackTrace

  /**
   * Method to get the Date and Time in a given moment eg.
   * when its called.
   *
   * @return String that represents Date and Time for a log as
   * eg.: [26/Sep/1998:10:28:23 +0200]
   */
  public String getLogDateTime() {
    return m_DateFormat.format(new Date());
  }//getLogDateTime

  /**
   * Sets the active flag, with true if the log should
   * be actively writing, false otherwise.
   *
   * @param b the required state of the log.
   */
  public void setActive(boolean b) {
    m_Active = b;
  }//setActive

  /**
   * Returns the state of the active flag,
   * which will be true if actively writing,
   * false if not.
   *
   * @return state of the active flag.
   */
  public boolean isActive() {
    return m_Active;
  }//isActive

  private static OutputStreamWriter prepareFileLog(String fpath)
      throws Exception {

    //filewriter stream
    return new FileWriter(new File(fpath));
  }//prepareLog

  /**
   * Overrides the Object finalize method to
   * flush and close the writer.
   */
  public void finalize() {
    try {
      write("Logging ended.");
      m_Writer.flush();
      m_Writer.close();
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }//finalize


//class operations

  /**
   * Factory method for a log that will write to an
   * abitrary OutputStream.
   *
   * @param stream OutputStream for log messages.
   * @param stampformat String that represents a valid Date formatter string.
   *
   * @return Log instance.
   */
  public static Log createStreamLog(OutputStream stream, String stampformat)
      throws Exception {
    return new Log(new OutputStreamWriter(stream), stampformat);
  }//createStreamLog


  /**
   * Factory method for a log that will write to a
   * File.
   *
   * @param fpath String that contains a valid path and filename.
   * @param stampformat String that represents a valid Date formatter string.
   *
   * @return Log instance.
   */
  public static Log createFileLog(String fpath, String stampformat)
      throws Exception {
    return new Log(prepareFileLog(fpath), stampformat);
  }//createLog


}//class Log
