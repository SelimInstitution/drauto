//License 
/***
 * Java TelnetD library (embeddable telnet daemon)
 * Copyright (c) 2000-04 Dieter Wimberger 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 * Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * Neither the name of the author nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *  
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTORS ``AS
 * IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 * POSSIBILITY OF SUCH DAMAGE.
 ***/
package net.wimpi.telnetd.net;

import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Enumeration;
import java.util.Vector;

/**
 * Class implementing a simple queue for connections
 * that the system cannot supply with full service.
 * <em>This class will most likely be removed, maybe
 * after a survey. Nowadays people won't wait like in
 * the old times of telnet.</em>
 *
 *
 * @author Dieter Wimberger
 * @version 1.0 (16/01/2004)
 */
public class ConnectionQueue {

  //Members
  private Vector m_QueuedConnections;	//data structure for queued conns
  private int m_MaxQueued;				//maximum queue capacity

  /**
   * Creates a Queue for our TelnetD
   * with a maximal size.
   */
  public ConnectionQueue(int size) {
    m_QueuedConnections = new Vector(size);
    m_MaxQueued = size;
  }//constructor

  /**
   * add an incoming connection to the queue if there is space
   * if not, inform the connector, and ask for retry in some time.
   */
  public void addToQueue(ConnectionData cd) {
    if (m_QueuedConnections.size() < m_MaxQueued) {
      m_QueuedConnections.addElement(cd);
      informQueued();
    } else {
      denyQueueing(cd);
    }
  }//addToQueue

  /**
   * called upon a logout occurance, returns the first one from the queue
   * and informs all queued via informQueued();
   * @return Socket that represents the first positioned User of the queue
   */
  public synchronized ConnectionData connectFromQueue() {
    ConnectionData nextOne = (ConnectionData) m_QueuedConnections.firstElement();
    m_QueuedConnections.removeElementAt(0);
    informQueued();
    return nextOne;
  }//connectFromQueue

  /**
   * Method to inform queued people of the invoked shutdown
   * gets rid of all queued after a nice message.
   */
  public synchronized void informQueuedOfShutdown() {
    int i = 0;

    for (Enumeration e = m_QueuedConnections.elements(); e.hasMoreElements();) {
      try {
        PrintStream out = getStream(((ConnectionData) e.nextElement()).getSocket());
        out.println("System wird niedergefahren. Bitte versuchs spaeter wieder.");
        out.println("System is shutting down. Please come back later.");
        out.println("El sistema esta acabando sus servicios. Favor de probar mas tarde.");
      } catch (IOException exc) {
        //handle by logging
      }
      m_QueuedConnections.removeElementAt(i++);
    }
  }//informedQueuedOfShutdown

  /**
   * Method to get the Queue Status.
   * @return Boolean true if users are queued or false if queue is empty
   */
  public boolean getQueueStatus() {
    if (m_QueuedConnections.size() != 0) {
      return true;
    } else {
      return false;
    }
  }//getQueueStatus

  /**
   * Method to inform queued people of their current position in the queue
   * gets rid of logged out users through removal on IOException when writing
   * something to the socket.
   */
  private synchronized void informQueued() {

    int i = 1;
    Socket queued = null;
    for (Enumeration e = m_QueuedConnections.elements();
         e.hasMoreElements(); i++) {

      try {
        queued = ((ConnectionData) e.nextElement()).getSocket();
        // FIXME: i18n
        getStream(queued).println("Queue nummer/number/numero [" + i + "]");
      } catch (IOException exc) {
        m_QueuedConnections.removeElement(queued);
      }
    }
  }//informQueued


  /**
   * deny queueing if there is no space any longer
   */
  private void denyQueueing(ConnectionData cd) {
    try {
      PrintStream out = getStream(cd.getSocket());
      out.println("Es tut uns leid, der Service und die Queue sind ausgelastet.");
      out.println("Bitte versuch es sp&auml;ter wieder.\n\n");
      out.println("Sorry, service and queue are full. Please come back later!\n");
      out.println("Lo sentemos, pero el servico y la queue son llenos. Favor de probar mas tarde.");
      //and close it :)
      cd.getSocket().close();
    } catch (IOException e) {
      //handle by logging maybe
    }
  }//denyQueueing

  /**
   * Method to get a Stream for a Socket
   * @param sock for which we want to create the output facility
   * @return PrintWriter output facility for a socket
   */
  private PrintStream getStream(Socket sock) throws IOException {
    return new PrintStream(sock.getOutputStream());
  }//getStream

}//class ConnectionQueue
