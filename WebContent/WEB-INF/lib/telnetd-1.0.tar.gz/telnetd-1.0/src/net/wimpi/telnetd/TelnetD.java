//License 
/***
 * Java TelnetD library (embeddable telnet daemon)
 * Copyright (c) 2000-04 Dieter Wimberger 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 * Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * Neither the name of the author nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *  
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTORS ``AS
 * IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 * POSSIBILITY OF SUCH DAMAGE.
 ***/
package net.wimpi.telnetd;

import java.util.Properties;
import java.util.Vector;
import java.io.File;

import net.wimpi.telnetd.io.terminal.TerminalManager;
import net.wimpi.telnetd.net.PortListener;
import net.wimpi.telnetd.shell.ShellManager;
import net.wimpi.telnetd.util.Log;
import net.wimpi.telnetd.util.PropertiesLoader;
import net.wimpi.telnetd.util.StringUtil;

/**
 * Class that implements a configurable and embeddable
 * telnet daemon.
 *
 * @author Dieter Wimberger
 * @version 1.0 (16/01/2004)
 */
public class TelnetD {

  //Associations
  private Vector m_Listeners;
  private ShellManager m_ShellManager;

  //Members
  private static Object c_Self = null;	//reference of the running singleton

  /**
   * <b>syslog</b>:
   * to be used for system messages
   */
  public static Log syslog;

  /**
   * <b>debuglog</b>:
   * to be used for debug message purposes
   */
  public static Log debuglog;

  /**
   * Constructor creating a TelnetD instance.<br>
   * Please always use the factory method to create the instance,
   * never the constructor itself.
   */
  private TelnetD() {
    c_Self = this;	//sets the singleton reference
    m_Listeners = new Vector(5);
  }//constructor

  /**
   * Method to toggle the serving state of the TelnetD:
   * <ol>
   * 		<li>true: The daemons listeners will accept and handle incoming connections.
   *		<li>false: The daemons listeners will neither accept nor handle incoming connections.
   * </ol>
   *
   * @param b boolean representing the required state.
   */
  public void setServing(boolean b) {
    for (int i = 0; i < m_Listeners.size(); i++) {
      ((PortListener) m_Listeners.elementAt(i)).setListening(b);
    }
  }//setServing

  /**
   * Tests if the daemon's listeners accept and handle incoming
   * connections.
   *
   * @return true if accepting and handling connections, false otherwise.
   */
  public boolean isServing() {
    for (int i = 0; i < m_Listeners.size(); i++) {
      if (!((PortListener) m_Listeners.elementAt(i)).isListening()) {
        return false;
      }
    }
    return true;
  }//isServing


  /**
   * Method to start serving.<br>
   *
   * @deprecated For simplification, replaced by setServing
   * @see #setServing(boolean)
   */
  public void startServing() {
    //it is a thread and we start it here
    setServing(true);
  }//startServing

  /**
   * Method to stop serving.<br>
   *
   * @deprecated For simplification, replaced by setServing
   * @see #setServing(boolean)
   */
  public void stopServing() {
    setServing(false);
  }//stopServing

  /**
   * Method to be called for complete system shutdown and cleanup.<br>
   * This will close down all attached connections of all listeners.
   */
  public void shutdown() {
    for (int i = 0; i < m_Listeners.size(); i++) {
      PortListener plis = (PortListener) m_Listeners.elementAt(i);
      //shutdown the Portlistener resources
      plis.shutdown();
      //stop the port listener thread
      plis.stop();
    }
  }//shutdown

  /**
   * Accessor method to version information.
   *
   * @return String that contains version information.
   */
  public String getVersion() {
    return VERSION;
  }//getVersion

  /**
   * Method to prepare the Daemon itself.<br>
   * Creates and prepares logging facilities mainly.
   *
   * @param settings Properties object that holds main settings.
   *
   * @throws BootException if preparation fails.
   */
  private void prepareDaemon(Properties settings)
      throws BootException {

    //check syslog first
    String setting = settings.getProperty("syslog");
    String path = settings.getProperty("syslog.path");
    String media = settings.getProperty("syslog.media");
    String stampformat = settings.getProperty("syslog.stampformat");
    syslog = prepareLog(setting, path, media, stampformat);

    setting = settings.getProperty("debuglog");
    path = settings.getProperty("debuglog.path");
    media = settings.getProperty("debuglog.media");
    stampformat = settings.getProperty("debuglog.stampformat");
    debuglog = prepareLog(setting, path, media, stampformat);

    //setup listeners
    //->
  }//prepareDaemon

  private Log prepareLog(String setting, String path, String media, String stampformat)
      throws BootException {

    Log lg = null;
    try {
      if (media == null || media.equals("") || media.equals("terminal")) {
        lg = Log.createStreamLog(System.out, stampformat);
      } else if (media.equals("file")) {
        lg = Log.createFileLog(path, stampformat);
      } else {
        throw new BootException("Unknown log media type.");
      }
    } catch (Exception ex) {
      throw new BootException("Creating log failed:" + ex.getMessage());
    }
    //ON/OFF decisions
    if (setting == null || setting.equals("") || setting.equals("off")) {
      //log is inactive
      lg.setActive(false);
    } else if (setting.equals("on")) {
      //log is active
      lg.setActive(true);
    } else {
      lg.setActive(false);
    }
    return lg;
  }//prepareLog

  /**
   * Method to prepare the ShellManager.<br>
   * Creates and prepares a Singleton instance of the ShellManager,
   * with settings from the passed in Properties.
   *
   * @param settings Properties object that holds main settings.
   *
   * @throws BootException if preparation fails.
   */
  private void prepareShellManager(Properties settings)
      throws BootException {

    //use factory method  for creating mgr singleton
    m_ShellManager = ShellManager.createShellManager(settings);
    if (m_ShellManager == null) {
      System.exit(1);
    }
  }//prepareShellManager


  /**
   * Method to prepare the PortListener.<br>
   * Creates and prepares and runs a PortListener, with settings from the
   * passed in Properties. Yet the Listener will not accept any incoming
   * connections before startServing() has been called. this has the advantage
   * that whenever a TelnetD Singleton has been factorized, it WILL 99% not fail
   * any longer (e.g. serve its purpose).
   *
   * @param settings Properties object that holds main settings.
   *
   * @throws BootException if preparation fails.
   */
  private void prepareListener(String name, Properties settings)
      throws BootException {

    //factorize PortListener
    PortListener listener = PortListener.createPortListener(name, settings);
    //start the Thread derived PortListener
    try {
      listener.start();
      m_Listeners.addElement(listener);
    } catch (Exception ex) {
      throw new BootException("Failure while starting PortListener thread: " + ex.getMessage());
    }

  }//prepareListener

  private void prepareTerminals(Properties terminals)
      throws BootException {

    TerminalManager.createTerminalManager(terminals);
  }//prepareTerminals


//Class operations



  /**
   * Factory method to create a TelnetD Instance.
   *
   * @param main Properties object with settings for the TelnetD.
   * @param shells Properties object with settings for the ShellManager.
   * @param terminals Properties object with settings for the TerminalManager.
   *
   * @return TenetD instance that has been properly set up according to the
   *         passed in properties, and is ready to start serving.
   *
   * @throws BootException if the setup process fails.
   */
  public static TelnetD createTelnetD(Properties main, Properties shells,
                                      Properties terminals, Properties[] listeners, String[] listenernames)
      throws BootException {

    if (c_Self == null) {
      TelnetD td = new TelnetD();
      td.prepareDaemon(main);
      td.prepareShellManager(shells);
      td.prepareTerminals(terminals);

      //prepare listeners.
      if (listeners == null || listeners.length == 0) {
        throw new BootException("No listener specified.");
      } else {
        for (int i = 0; i < listeners.length; i++) {
          td.prepareListener(listenernames[i],listeners[i]);
        }
      }
      return td;
    } else {
      throw new BootException("Singleton already instantiated.");
    }

  }//createTelnetD

  /**
   * Factory method to create a TelnetD Instance.
   *
   * @param main Properties object with settings for the TelnetD.
   * @return TenetD instance that has been properly set up according to the
   *         passed in properties, and is ready to start serving.
   *
   * @throws BootException if the setup process fails.
   */
  public static TelnetD createTelnetD(Properties main)
      throws BootException {

    if (c_Self == null) {
      TelnetD td = new TelnetD();
      td.prepareDaemon(main);
      td.prepareShellManager(main);
      td.prepareTerminals(main);
      String[] listnames = StringUtil.split(main.getProperty("listeners"), ",");
      for (int i = 0; i < listnames.length; i++) {
        td.prepareListener(listnames[i], main);
      }
      return td;
    } else {
      throw new BootException("Singleton already instantiated.");
    }

  }//createTelnetD

  /**
   * Factory method to create a TelnetD singleton instance,
   * loading the standard properties files from the given
   * String containing an URL location.<br>
   *
   * @param urlprefix String containing an URL prefix.
   *
   * @return TenetD instance that has been properly set up according to the
   *         passed in properties, and is ready to start serving.
   *
   * @throws BootException if the setup process fails.
   */
  public static TelnetD createTelnetD(String urlprefix)
      throws BootException {

    Properties main = null;
    Properties shells = null;
    Properties terminals = null;
    Properties[] listeners = null;

    if (c_Self == null) {
      try {
        System.out.println("Loading telnetd");
        boolean unifiedprops = false;
        if(urlprefix.indexOf(File.separator) == -1) {
          //relative
          urlprefix=new File(urlprefix).toURL().toString();
        }
        if(urlprefix.endsWith(".properties")) {
          unifiedprops = true;
          main = PropertiesLoader.loadProperties(urlprefix);
          shells = main;
          terminals = main;
        } else {
          main = PropertiesLoader.loadProperties(urlprefix + "/" + PROPERTIES_MAIN);
          shells = PropertiesLoader.loadProperties(urlprefix + "/" + PROPERTIES_SHELLS);
          terminals = PropertiesLoader.loadProperties(urlprefix + "/" + PROPERTIES_TERMINALS);
        }
        String[] listnames = StringUtil.split(main.getProperty("listeners"), ",");
        if (listnames == null || listnames.length == 0) {
          throw new BootException("No listener specified.");
        } else {
          listeners = new Properties[listnames.length];
          for (int i = 0; i < listnames.length; i++) {
            if(unifiedprops) {
              listeners[i] = main;
            } else {
              listeners[i] = PropertiesLoader.loadProperties(urlprefix + "/" + listnames[i] + PROPERTIES_LISTENER_SUFFIX);
            }
          }
        }
        return createTelnetD(main, shells, terminals, listeners, listnames);
      } catch (Exception ex) {
        //debuglog.writeStackTrace(ex);
        throw new BootException(ex.getMessage());
      }
    } else {
      throw new BootException("Singleton already instantiated.");
    }
  }//createTelnetD

  /**
   * Accessor method for the Singleton instance of this class.<br>
   *
   * @return TelnetD Singleton instance reference.
   */
  public static TelnetD getReference() {
    if (c_Self != null) {
      return ((TelnetD) c_Self);
    } else {
      return null;
    }
  }//getReference

  /**
   * Implements a test startup of an example server.
   * It is supposed to demonstrate the easy deployment,
   * and usage of this daemon.<br>
   * <em>Usage:</em><br>
   * <code>java net.wimpi.telnetd.TelnetD [URL prefix pointing to properties]</code>
   *
   * @param args String array containing arguments.
   */
  public static void main(String[] args) {
    TelnetD myTD = null;

    try {
      //1. prepare daemon
      if (args.length == 0) {
        System.out.println("\nUsage: java net.wimpi.telnetd.TelnetD urlprefix\n");
        System.out.println("         java net.wimpi.telnetd.TelnetD url\n");
        System.exit(1);
      } else {
        myTD = TelnetD.createTelnetD(args[0]);
      }
      //2.start serving/accepting connections
      myTD.setServing(true);

    } catch (Exception ex) {
      ex.printStackTrace();
      System.exit(1);
    }
  }//main

  private static final String VERSION = "1.0";
  private static final String PROPERTIES_MAIN = "daemon.properties";
  private static final String PROPERTIES_SHELLS = "shells.properties";
  private static final String PROPERTIES_TERMINALS = "terminals.properties";
  private static final String PROPERTIES_LISTENER_SUFFIX = "-listener.properties";

}//class TelnetD
