//License 
/***
 * Java TelnetD library (embeddable telnet daemon)
 * Copyright (c) 2000-04 Dieter Wimberger 
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 * Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * Neither the name of the author nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *  
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTORS ``AS
 * IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 * POSSIBILITY OF SUCH DAMAGE.
 ***/
package net.wimpi.telnetd.net;

import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.text.MessageFormat;
import java.util.Enumeration;
import java.util.Properties;
import java.util.Vector;

import net.wimpi.telnetd.BootException;
import net.wimpi.telnetd.TelnetD;

/**
 * Class that takes care for active and queued connection.
 * Housekeeping is done also for connections that were just broken
 * off, or exceeded their timeout. Note that instances of this class can
 * only be created by using the factory method createConnectionManager(Properties settings).
 *
 *  @author Dieter Wimberger
 *  @version 1.0 (16/01/2004)
 */
public class ConnectionManager
    extends Thread {

  //Members
  private ThreadGroup m_ThreadGroup;	//ThreadGroup all connections run in
  private Vector m_Connections;		//vector holding managed connections
  private Vector m_Broken;	//vector holding connections that are broken
  private Vector m_Closed;	//vectore holding closed connections

  private ConnectionQueue m_Queue;		//reference to the connection queue
  private ConnectionFilter m_Filter; //reference to the connection filter
  private boolean m_Active;				//flag if thread is supposed to be running


  private int m_MaxConnections;			//maximum allowed connections stored from the properties
  private int m_WarningTimeout;		//time to idle warning
  private int m_DisconnectTimeout;		//time to idle diconnection
  private int m_HousekeepingInterval;	//interval for managing cleanups
  private String m_LoginShell;
  private boolean m_LineMode = false;


  private ConnectionManager(int con, int queue, int timew, int timedis,
                            int hoke, ConnectionFilter filter,
                            String lsh, boolean lm) {
    m_ThreadGroup = new ThreadGroup("Connections");
    m_Connections = new Vector(con);
    m_Connections.ensureCapacity(con);

    m_Broken = new Vector(20);
    m_Closed = new Vector(20);

    m_Queue = new ConnectionQueue(queue);
    m_Filter = filter;
    m_LoginShell = lsh;
    m_LineMode = lm;

    m_MaxConnections = con;
    m_WarningTimeout = timew;
    m_DisconnectTimeout = timedis;
    m_HousekeepingInterval = hoke;
    m_Active = true;
  }//constructor


  /** Management thread methods ***********************/

  /**
   * Housekeeping thread's run method.<br>
   * Periodically does following work:
   * <ul>
   *   <li> cleaning up died connections.
   *   <li> checking managed connections if they are working properly.
   *   <li> checking the queued connections.
   * </ul>
   */
  public void run() {
    //housekeep connections
    try {
      while (m_Active) {
        //clean up and stop all closed connections
        cleanupClosed();
        //clean up and close all broken connections
        cleanupBroken();

        //check all active connections
        checkConnections();
        checkQueue();

        //and now sleep again
        this.sleep(m_HousekeepingInterval);
      }
    } catch (Exception e) {
      TelnetD.debuglog.writeStackTrace(e);
    }
  }//run

  private void cleanupClosed() {
    //cleanup loop
    while (m_Closed.size() != 0) {
      //get a closed one
      Connection nextOne = (Connection) m_Closed.firstElement();
      TelnetD.debuglog.write(this.toString() + ":Cleaning up closed connection:" + nextOne.toString());

      //stop the thread
      nextOne.stop();
      //remove it from the vector
      m_Closed.removeElementAt(0);
      //try to connect a queued connection into the free connection resource
      if (m_Queue.getQueueStatus()) {
        connect(m_Queue.connectFromQueue());
      }

      //remove it from the collection of active connections.
      m_Connections.removeElement(nextOne);
    }
  }//cleanupClosed

  private void cleanupBroken() {
    //cleanup loop
    while (m_Broken.size() != 0) {
      //get a died one
      Connection nextOne = (Connection) m_Broken.firstElement();
      TelnetD.debuglog.write(this.toString() + ":Closing broken connection:" + nextOne.toString());
      //fire logoff event for shell site cleanup , beware could hog the daemon thread
      nextOne.processConnectionEvent(new ConnectionEvent(nextOne, ConnectionEvent.CONNECTION_BROKEN));

      //close the connection, will be automatically registered as closed
      nextOne.close();

      //remove it from the broken collection
      m_Broken.removeElementAt(0);
    }
  }//cleanupBroken

  private void checkConnections() {
    //do routine checks on active connections
    for (Enumeration enum = m_Connections.elements(); enum.hasMoreElements();) {
      Connection conn = (Connection) enum.nextElement();
      ConnectionData cd = conn.getConnectionData();
      /* Timeouts check */
      //first we caculate the inactivity time
      long inactivity = System.currentTimeMillis() - cd.getLastActivity();
      //now we check for warning and disconnection
      if (inactivity > m_WarningTimeout) {
        //..and for disconnect
        if (inactivity > (m_DisconnectTimeout + m_WarningTimeout)) {
          //this connection needs to be disconnected :)
          TelnetD.debuglog.write(conn.toString() + " exceeded total timeout.");
          //fire logoff event for shell site cleanup , beware could hog the daemon thread
          conn.processConnectionEvent(new ConnectionEvent(conn, ConnectionEvent.CONNECTION_TIMEDOUT));
          //conn.close();
        } else {
          //this connection needs to be warned :)
          if (!cd.isWarned()) {
            TelnetD.debuglog.write(conn.toString() + " exceeded warning timeout.");
            cd.setWarned(true);
            //warning event is fired but beware this could hog the daemon thread!!
            conn.processConnectionEvent(new ConnectionEvent(conn, ConnectionEvent.CONNECTION_IDLE));
          }
        }
      }
      /* end Timeouts check */

      //add further checks here
    }
  }//checkConnections


  private void checkQueue() {
    //do routine low level checks on queued connections
  }//checkQueue


  /**
   * Called by connections that got broken (i.e. I/O errors).
   * The housekeeper will properly close the connection,
   * and take care for misc necessary cleanup.
   *
   * @param con the connection that is broken.
   */
  public void registerBrokenConnection(Connection con) {
    if (!m_Broken.contains(con)) {
      m_Broken.addElement(con);
    }
  }//registerBrokenConnection

  /**
   * Called by connections after they closed. The housekeeper
   * will properly stop the thread and take care for
   * misc necessary cleanup.
   *
   * @param con the connection that has been closed.
   */
  public void registerClosedConnection(Connection con) {
    if (!m_Closed.contains(con)) {
      m_Closed.addElement(con);
    }
    System.out.println("Registered closed connection.");
  }//registerClosedConnection

  /** END Management thread methods **************************************/


  /** Manager Methods ****************************************************/

  /**
   * Method that that tries to connect an incoming request.
   * Properly  queueing.
   *
   * @param insock Socket thats representing the incoming connection.
   */
  public void makeConnection(Socket insock) {

    if (m_Filter == null ||
        (m_Filter != null && m_Filter.isAllowed(insock.getInetAddress()))) {

      //we create the connection data object at this point to
      //store certain information there.
      ConnectionData newCD = new ConnectionData(insock, this);
      newCD.setLoginShell(m_LoginShell);
      newCD.setLineMode(m_LineMode);
      TelnetD.debuglog.write("Linemode=" + m_LineMode);

      if (m_Connections.size() < m_MaxConnections) {
        connect(newCD);
      } else {
        m_Queue.addToQueue(newCD);
      }
    } else {
      //close it down and don't waste further resources for
      //banned site
      try {
        insock.close();
      } catch (IOException ex) {
        //do nothing or log.
      }
    }
  }//makeConnection

  /**
   * Method that really sets up an active TelnetConnection Object when
   * resource limits and availability have been ensured.
   */
  private void connect(ConnectionData cd) {

    //create a new Connection instance
    Connection con = new Connection(m_ThreadGroup, cd);
    //log the newly created connection
    Object[] args = {new Integer(m_Connections.size() + 1)};
    TelnetD.syslog.write(MessageFormat.format("connection #{0,number,integer} made.", args));
    //register it for being managed
    m_Connections.addElement(con);
    //start the thread
    con.start();
  }//connect

  /**
   * Method that will properly shut all connections managed
   * by this ConnectionManager instance.
   *
   */
  public void shutdown() {
    //deactivate
    m_Active = false;
    //shutdown all queued connections
    m_Queue.informQueuedOfShutdown();
    //shutdown all full connections
    informConnectedOfShutdown();
  }//shutdown

  /**
   * Set a connection filter for this
   * ConnectionManager instance. The filter is used to handle
   * IP level allow/deny of incoming connections.
   *
   * @param filter ConnectionFilter instance.
   */
  public void setConnectionFilter(ConnectionFilter filter) {
    m_Filter = filter;
  }//setConnectionFilter

  /**
   * Gets the active ConnectionFilter instance or
   * returns null if no filter is set.
   *
   * @return the managers ConnectionFilter.
   */
  public ConnectionFilter getConnectionFilter() {
    return m_Filter;
  }//getConnectionFilter

  /**
   * Method to inform connected people of the invoked shutdown
   * it gets rid of all after the nice message.
   */
  private synchronized void informConnectedOfShutdown() {
    for (Enumeration e = m_Connections.elements(); e.hasMoreElements();) {
      try {
        Connection tc = (Connection) e.nextElement();
        //maybe write a disgrace to the socket?
        tc.close();
      } catch (Exception exc) {
        TelnetD.syslog.writeStackTrace(exc);
      }
    }
    m_Connections.removeAllElements();
  }//informConnectedOfShutdown

  /**
   * Method to get a Stream for a Socket
   *
   * @param sock for which we want to create the output facility
   * @return PrintWriter output facility for a socket
   */
  private PrintStream getStream(Socket sock)
      throws IOException {

    return new PrintStream(sock.getOutputStream());
  }//getStream


  /**
   * Factory method for the ConnectionManager.<br>
   * A class operation that will return a new ConnectionManager instance.
   *
   * @param settings Properties containing the settings for this instance.
   */
  public static ConnectionManager createConnectionManager(String name, Properties settings)
      throws BootException {

    try {
      int maxc = Integer.parseInt(settings.getProperty(name + ".maxcon"));
      int maxq = Integer.parseInt(settings.getProperty(name + ".maxqueued"));
      int timow = Integer.parseInt(settings.getProperty(name + ".time_to_warning"));
      int timodis = Integer.parseInt(settings.getProperty(name + ".time_to_timedout"));
      int hoke = Integer.parseInt(settings.getProperty(name + ".housekeepinginterval"));
      String filterclass = settings.getProperty(name + ".connectionfilter");
      ConnectionFilter filter = null;
      String loginshell = "";
      boolean linemode = false;
      if (filterclass != null && filterclass.length() != 0 && !filterclass.toLowerCase().equals("none")) {
        //load filter
        filter = (ConnectionFilter) Class.forName(filterclass).newInstance();
        filter.initialize(settings);
      }
      loginshell = settings.getProperty(name + ".loginshell");
      if (loginshell == null || loginshell.length() == 0) {
        TelnetD.debuglog.write("Login shell not specified.");
        throw new Exception();
      }
      String inputmode = settings.getProperty(name + ".inputmode");
      if (inputmode == null || inputmode.length() == 0) {
        TelnetD.debuglog.write("Input mode not specified using character as default.");
        linemode = false;
      } else if (inputmode.toLowerCase().equals("line")) {
        linemode = true;
      }
      //return fabricated manager
      ConnectionManager cm = new ConnectionManager(maxc, maxq, timow, timodis, hoke, filter, loginshell, linemode);
      //set higher priority!
      cm.setPriority(Thread.NORM_PRIORITY + 2);
      return cm;
    } catch (Exception ex) {
      TelnetD.syslog.writeStackTrace(ex);
      throw new BootException("Failure while creating ConnectionManger instance:\n" + ex.getMessage());
    }
  }//createManager


}//class ConnectionManager
